<?php

$tasks = array(
    array(
        'classname' => 'plagiarism_tomagrade\task\sendfiles',
        'blocking' => 0,
        'minute' => '*/15',
        'hour' => '*',
        'day' => '*',
        'dayofweek' => '*',
        'month' => '*'
    )
);
